/*var asignarElemento = function(){
			var content = document.getElementById("texto1").value;
			var existeP = document.getElementByTagName("p");
			if(existeP.length > 0){
				existeP[0].innerHTML = content;
			}
			else {
				var elementoP = document.createElement("p");
				elementoP.innerHTML = content;
				var elementoDiv = document.getElementById("miDiv");
				elementoDiv.appendChild(elementoP);
			}		
		}*/
		
		// Vamos a asignar estilo con JS
		
		var miDiv = document.getElementById("miDiv");
		//miDiv.setAttribute("class", "azul");
		// o
		miDiv.className = "azul";